"""Handwritten Mathematical Symbol Recognition using a CNN (TensorFlow / Keras).

Expected data layout (one folder per symbol class):
    data/
        0/ 1/ 2/ ... plus/ minus/ times/ div/ equals/ ...   (the 20 classes you choose)

Run:  python train_cnn.py --data_dir data --out_dir outputs
Writes: outputs/results.json, training_curves.png, confusion_cnn.png,
        sample_predictions.png, cnn_symbols.keras, class_names.json
"""
import argparse, json, platform, random, time
from datetime import date
from pathlib import Path

import numpy as np
from PIL import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (accuracy_score, confusion_matrix,
                             precision_recall_fscore_support)
from sklearn.model_selection import train_test_split

import keras
import tensorflow as tf
from keras import layers

from common import IMG, SEED, EXTS, preprocess_image


def load_dataset(data_dir, max_per_class):
    root = Path(data_dir)
    names = sorted(p.name for p in root.iterdir() if p.is_dir())
    rng = random.Random(SEED)
    X, y = [], []
    for idx, name in enumerate(names):
        files = sorted(f for f in (root / name).iterdir() if f.suffix.lower() in EXTS)
        rng.shuffle(files)
        for f in files[:max_per_class]:
            X.append(preprocess_image(Image.open(f)))
            y.append(idx)
    X = np.asarray(X, dtype=np.float32)[..., None]      # (N, 32, 32, 1)
    return X, np.asarray(y, dtype=np.int64), names


def augmentation():
    kw = dict(fill_mode="constant", fill_value=0.0)      # black background, active only in training
    return [layers.RandomRotation(0.03, **kw),           # about +/-10 degrees
            layers.RandomTranslation(0.1, 0.1, **kw),
            layers.RandomZoom(0.1, **kw)]


def build_cnn(n_classes):
    return keras.Sequential([
        keras.Input(shape=(IMG, IMG, 1)), *augmentation(),
        layers.Conv2D(32, 3, activation="relu", padding="same"), layers.MaxPooling2D(2),
        layers.Conv2D(64, 3, activation="relu", padding="same"), layers.MaxPooling2D(2),
        layers.Conv2D(128, 3, activation="relu", padding="same"), layers.MaxPooling2D(2),
        layers.Flatten(), layers.Dense(128, activation="relu"), layers.Dropout(0.5),
        layers.Dense(n_classes, activation="softmax")], name="cnn")


def build_mlp(n_classes):
    return keras.Sequential([
        keras.Input(shape=(IMG, IMG, 1)), *augmentation(), layers.Flatten(),
        layers.Dense(512, activation="relu"), layers.Dense(256, activation="relu"),
        layers.Dropout(0.5), layers.Dense(n_classes, activation="softmax")], name="mlp")


def train_and_eval(model, data, args):
    (Xtr, ytr), (Xva, yva), (Xte, yte) = data
    model.compile(optimizer=keras.optimizers.Adam(1e-3),
                  loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    stop = keras.callbacks.EarlyStopping(monitor="val_loss", patience=5,
                                         restore_best_weights=True)
    t0 = time.perf_counter()
    hist = model.fit(Xtr, ytr, validation_data=(Xva, yva), epochs=args.epochs,
                     batch_size=args.batch_size, callbacks=[stop], verbose=2)
    train_time = time.perf_counter() - t0

    pred = model.predict(Xte, batch_size=256, verbose=0).argmax(axis=1)
    p, r, f1, _ = precision_recall_fscore_support(yte, pred, average="macro", zero_division=0)
    times = []
    for i in range(min(210, len(Xte))):                  # single-image inference time
        t = time.perf_counter(); model(Xte[i:i + 1], training=False)
        times.append((time.perf_counter() - t) * 1000)
    h = hist.history
    res = dict(accuracy=float(accuracy_score(yte, pred)), precision=float(p), recall=float(r),
               f1=float(f1), epochs=len(h["loss"]), time_s=float(train_time),
               params=int(model.count_params()), infer_ms=float(np.median(times[10:])),
               final_train_acc=float(h["accuracy"][-1]), final_val_acc=float(h["val_accuracy"][-1]))
    return res, hist.history, pred


def plot_curves(h, path):
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.4))
    ep = range(1, len(h["loss"]) + 1)
    ax[0].plot(ep, h["accuracy"], "o-", ms=3, label="training")
    ax[0].plot(ep, h["val_accuracy"], "s-", ms=3, label="validation")
    ax[0].set(title="CNN accuracy", xlabel="Epoch", ylabel="Accuracy")
    ax[1].plot(ep, h["loss"], "o-", ms=3, label="training")
    ax[1].plot(ep, h["val_loss"], "s-", ms=3, label="validation")
    ax[1].set(title="CNN loss", xlabel="Epoch", ylabel="Loss")
    for a in ax: a.grid(alpha=.3); a.legend()
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)


def plot_confusion(cm, names, path):
    fig, ax = plt.subplots(figsize=(7, 6))
    ax.imshow(cm, cmap="Blues")
    n = len(names)
    ax.set_xticks(range(n)); ax.set_xticklabels(names, rotation=90, fontsize=7)
    ax.set_yticks(range(n)); ax.set_yticklabels(names, fontsize=7)
    ax.set(xlabel="Predicted", ylabel="Actual", title="CNN confusion matrix (test set)")
    for i in range(n):
        for j in range(n):
            if cm[i, j]:
                ax.text(j, i, cm[i, j], ha="center", va="center", fontsize=5,
                        color="white" if cm[i, j] > cm.max() / 2 else "black")
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)


def plot_samples(X, y, pred, names, path, k=8):
    ok = np.where(y == pred)[0][:k]
    bad = np.where(y != pred)[0][:k]
    idx = list(ok) + list(bad)
    cols = max(len(ok), len(bad), 1)
    fig, ax = plt.subplots(2, cols, figsize=(1.3 * cols, 3.0), squeeze=False)
    for a in ax.ravel(): a.axis("off")
    for row, group in enumerate((ok, bad)):
        for c, i in enumerate(group):
            ax[row, c].imshow(X[i, ..., 0], cmap="gray")
            ax[row, c].set_title(f"true {names[y[i]]}\npred {names[pred[i]]}", fontsize=7,
                                 color="green" if y[i] == pred[i] else "red")
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="data")
    ap.add_argument("--out_dir", default="outputs")
    ap.add_argument("--max_per_class", type=int, default=2000)
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--batch_size", type=int, default=128)
    args = ap.parse_args()
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    keras.utils.set_random_seed(SEED)

    X, y, names = load_dataset(args.data_dir, args.max_per_class)
    n_classes = len(names)
    print(f"{len(X)} images, {n_classes} classes: {names}")
    Xtr, Xtmp, ytr, ytmp = train_test_split(X, y, test_size=0.30, stratify=y, random_state=SEED)
    Xva, Xte, yva, yte = train_test_split(Xtmp, ytmp, test_size=0.50, stratify=ytmp,
                                          random_state=SEED)
    data = ((Xtr, ytr), (Xva, yva), (Xte, yte))

    cnn = build_cnn(n_classes); cnn.summary()
    res_cnn, hist, pred = train_and_eval(cnn, data, args)
    mlp = build_mlp(n_classes)
    res_mlp, _, _ = train_and_eval(mlp, data, args)

    cm = confusion_matrix(yte, pred, labels=range(n_classes))
    off = [(int(cm[i, j]), names[i], names[j]) for i in range(n_classes)
           for j in range(n_classes) if i != j and cm[i, j] > 0]
    top = [dict(true=t, pred=p, count=c) for c, t, p in sorted(off, reverse=True)[:5]]
    p_, r_, f_, s_ = precision_recall_fscore_support(yte, pred, labels=range(n_classes),
                                                     zero_division=0)
    per_class = [dict(name=names[i], precision=float(p_[i]), recall=float(r_[i]),
                      f1=float(f_[i]), support=int(s_[i])) for i in range(n_classes)]

    results = dict(date=date.today().isoformat(), python=platform.python_version(),
                   tensorflow=tf.__version__, system=platform.system(),
                   dataset=dict(n_images=int(len(X)), n_train=int(len(Xtr)), n_val=int(len(Xva)),
                                n_test=int(len(Xte)), n_classes=n_classes,
                                per_class_cap=args.max_per_class, classes=names),
                   cnn=res_cnn, mlp=res_mlp, top_confusions=top, per_class=per_class)
    (out / "results.json").write_text(json.dumps(results, indent=2))
    (out / "class_names.json").write_text(json.dumps(names))
    cnn.save(out / "cnn_symbols.keras")
    plot_curves(hist, out / "training_curves.png")
    plot_confusion(cm, names, out / "confusion_cnn.png")
    plot_samples(Xte, yte, pred, names, out / "sample_predictions.png")
    print(json.dumps({k: results[k] for k in ("cnn", "mlp", "top_confusions")}, indent=2))


if __name__ == "__main__":
    main()
