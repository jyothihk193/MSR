"""Predict the symbol in one image:  python predict.py my_symbol.png [--model_dir outputs]"""
import argparse, json
from pathlib import Path

import numpy as np
from PIL import Image
import keras

from common import preprocess_image

ap = argparse.ArgumentParser()
ap.add_argument("image")
ap.add_argument("--model_dir", default="outputs")
ap.add_argument("--min_conf", type=float, default=0.5)
args = ap.parse_args()

model = keras.models.load_model(Path(args.model_dir) / "cnn_symbols.keras")
names = json.loads((Path(args.model_dir) / "class_names.json").read_text())
x = preprocess_image(Image.open(args.image))[None, ..., None]
probs = model(x, training=False).numpy()[0]
for i in np.argsort(probs)[::-1][:3]:
    print(f"{names[i]:>10s}  {probs[i]:.3f}")
if probs.max() < args.min_conf:
    print("Low confidence: the symbol may be outside the trained classes.")
