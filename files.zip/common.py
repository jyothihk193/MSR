"""Shared preprocessing for training and prediction (one function, no train-serve mismatch)."""
import numpy as np
from PIL import Image

IMG = 32          # every symbol image becomes IMG x IMG pixels
SEED = 42
EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


def preprocess_image(img: Image.Image) -> np.ndarray:
    """PIL image -> float32 array (IMG, IMG) with bright strokes on a dark background, 0..1."""
    g = np.asarray(img.convert("L").resize((IMG, IMG), Image.BILINEAR), dtype=np.float32)
    if g.mean() > 127:          # dark ink on white paper -> invert
        g = 255.0 - g
    return g / 255.0
