"""Builds the mini-project report PDF.

    python build_report.py [results_dir]        (default results_dir = outputs)

If <results_dir>/results.json (written by train_cnn.py) exists, every number, table and
result figure is filled in from it.  Otherwise the result fields are shown as yellow
[placeholders] so the layout can be checked first.
"""
import json, sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle
from PIL import Image as PILImage

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, Frame, PageTemplate, NextPageTemplate, Paragraph,
                                Spacer, PageBreak, Table, TableStyle, Image, KeepTogether,
                                Preformatted)
from reportlab.graphics.shapes import Drawing, Rect, String

# ----------------------------------------------------------------- edit these if needed
TITLE = "HANDWRITTEN MATHEMATICAL SYMBOL RECOGNITION USING DEEP LEARNING (CNN)"
STUDENT = "SNEHA BHIMARAO MELSHETTY"
USN = "1DB23IS152"
GUIDE = "Mrs. CHAITRA A S"
GUIDE_POST = "Assistant Professor, Dept. of ISE"
YEAR = "2026-27"
REPO_URL = ""            # e.g. "https://github.com/<user>/<repo>"  (empty -> placeholder)
# -----------------------------------------------------------------------------------------

HERE = Path(__file__).resolve().parent
RES = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "outputs"
FIG = HERE / "figs"; FIG.mkdir(exist_ok=True)
OUT = HERE / "Math_Symbol_Recognition_Mini_Project_Report.pdf"
RED = colors.HexColor("#C0272D")
HL = "#FFF200"

R = json.loads((RES / "results.json").read_text()) if (RES / "results.json").exists() else None

# ------------------------------------------------------------------ fonts
# Liberation (Linux) or Times New Roman / Courier New (Windows); first set found is used.
FONT_SETS = [("/usr/share/fonts/truetype/liberation/",
              ["LiberationSerif-Regular.ttf", "LiberationSerif-Bold.ttf", "LiberationSerif-Italic.ttf",
               "LiberationSerif-BoldItalic.ttf", "LiberationMono-Regular.ttf"], "Liberation Serif"),
             ("C:/Windows/Fonts/", ["times.ttf", "timesbd.ttf", "timesi.ttf", "timesbi.ttf", "cour.ttf"],
              "Times New Roman")]
for base, files, mpl_name in FONT_SETS:
    if all(Path(base + f).exists() for f in files):
        for name, f in zip(("Serif", "Serif-B", "Serif-I", "Serif-BI", "Mono"), files):
            pdfmetrics.registerFont(TTFont(name, base + f))
            font_manager.fontManager.addfont(base + f)
        plt.rcParams["font.family"] = mpl_name
        break
else:
    sys.exit("No usable fonts found: edit FONT_SETS in build_report.py (a Times-like .ttf set).")
pdfmetrics.registerFontFamily("Serif", normal="Serif", bold="Serif-B", italic="Serif-I",
                              boldItalic="Serif-BI")

# ------------------------------------------------------------------ result helpers
def ph(t):
    return f'<font backColor="{HL}">[{t}]</font>'

def g(*keys):
    d = R
    if d is None: return None
    for k in keys:
        d = d[k]
    return d

def num(keys, fmt, label):
    v = g(*keys)
    return ph(label) if v is None else format(v, fmt)

# ------------------------------------------------------------------ diagrams
def box(ax, cx, cy, w, h, title, sub=None, fc="#FFFFFF", fs=8.5, subfs=6.6):
    ax.add_patch(Rectangle((cx - w / 2, cy - h / 2), w, h, fc=fc, ec="#222222", lw=0.9))
    if sub:
        ax.text(cx, cy + h * 0.20, title, ha="center", va="center", fontsize=fs, fontweight="bold")
        ax.text(cx, cy - h * 0.18, sub, ha="center", va="center", fontsize=subfs, linespacing=1.3)
    else:
        ax.text(cx, cy, title, ha="center", va="center", fontsize=fs, fontweight="bold")

def arrow(ax, x1, y1, x2, y2):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", lw=0.9, color="#222222", shrinkA=0, shrinkB=0))

def save(fig, name):
    fig.savefig(FIG / name, dpi=300, bbox_inches="tight", pad_inches=0.06); plt.close(fig)

def fig_conv():
    img = np.zeros((8, 8)); img[3:5, 1:7] = 1; img[1:7, 3:5] = 1       # a thick "+" symbol
    K = np.array([[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]])
    out = np.array([[(img[i:i + 3, j:j + 3] * K).sum() for j in range(6)] for i in range(6)])
    fig, ax = plt.subplots(1, 3, figsize=(7.4, 2.7), gridspec_kw=dict(width_ratios=[1, .75, 1]))
    ax[0].imshow(img, cmap="Greys", vmin=0, vmax=1.3)
    ax[0].add_patch(Rectangle((0.5, 1.5), 3, 3, fc="none", ec="#C0272D", lw=2))
    ax[0].set_title("Input image (8 x 8)", fontsize=9, fontweight="bold")
    ax[1].imshow(np.zeros((3, 3)), cmap="Greys", vmin=0, vmax=1, alpha=0.04)
    for i in range(3):
        for j in range(3):
            ax[1].text(j, i, f"{K[i, j]:+d}".replace("+0", "0"), ha="center", va="center", fontsize=11)
    ax[1].add_patch(Rectangle((-0.5, -0.5), 3, 3, fc="none", ec="#C0272D", lw=2))
    ax[1].set_title("Filter (3 x 3)", fontsize=9, fontweight="bold")
    ax[2].imshow(out, cmap="RdBu_r", vmin=-4, vmax=4)
    ax[2].set_title("Feature map (6 x 6)", fontsize=9, fontweight="bold")
    for a in ax:
        a.set_xticks([]); a.set_yticks([])
    fig.text(0.5, -0.03, "The same filter weights are reused at every position, so a stroke is "
             "found wherever it occurs.", ha="center", fontsize=7.5, style="italic")
    fig.tight_layout(); save(fig, "fig_conv.png")

def fig_pool():
    M = np.array([[1, 3, 2, 1], [4, 6, 5, 0], [7, 2, 9, 8], [3, 1, 4, 6]])
    P = np.array([[M[:2, :2].max(), M[:2, 2:].max()], [M[2:, :2].max(), M[2:, 2:].max()]])
    cols = ["#F6D5D5", "#D9E6F5", "#DDF0DA", "#FBEBC8"]
    fig, ax = plt.subplots(figsize=(6.0, 2.3)); ax.set_xlim(0, 15); ax.set_ylim(-0.4, 5.3); ax.axis("off")
    for i in range(4):
        for j in range(4):
            c = cols[(i // 2) * 2 + (j // 2)]
            ax.add_patch(Rectangle((1 + j, 3.6 - i), 1, 1, fc=c, ec="#333", lw=0.8))
            ax.text(1.5 + j, 4.1 - i, str(M[i, j]), ha="center", va="center", fontsize=11)
    for i in range(2):
        for j in range(2):
            ax.add_patch(Rectangle((9 + j, 3.1 - i), 1, 1, fc=cols[i * 2 + j], ec="#333", lw=0.8))
            ax.text(9.5 + j, 3.6 - i, str(P[i, j]), ha="center", va="center", fontsize=11, fontweight="bold")
    arrow(ax, 5.4, 3.1, 8.6, 3.1)
    ax.text(7.0, 3.5, "max over each\n2 x 2 block", ha="center", fontsize=8)
    ax.text(3, 5.0, "Feature map (4 x 4)", ha="center", fontsize=9, fontweight="bold")
    ax.text(10, 5.0, "After pooling (2 x 2)", ha="center", fontsize=9, fontweight="bold")
    ax.text(7.5, -0.3, "Pooling halves the width and height and keeps the strongest response.",
            ha="center", fontsize=7.5, style="italic")
    save(fig, "fig_pool.png")

def fig_system():
    fig, ax = plt.subplots(figsize=(7.2, 5.4)); ax.set_xlim(0, 100); ax.set_ylim(-5, 82); ax.axis("off")
    box(ax, 50, 76, 58, 8, "Handwritten symbol images", "one folder per class  |  20 classes")
    box(ax, 50, 64, 58, 8, "Preprocessing (common.py)", "grayscale  |  32 x 32  |  polarity fix  |  scale 0 to 1")
    box(ax, 50, 52, 58, 8, "Stratified split 70 / 15 / 15", "train  |  validation  |  test (seed 42)")
    ax.add_patch(Rectangle((4, 21), 92, 25, fc="#F7E4E4", ec="#C0272D", lw=1, ls="--"))
    ax.text(94, 43.5, "TRAINING (train_cnn.py)", ha="right", va="center", fontsize=7.5,
            color="#C0272D", fontweight="bold")
    box(ax, 27, 31, 40, 11, "CNN (main model)", "augment \u2192 3 \u00d7 (Conv + Pool)\n\u2192 Dense \u2192 Softmax", fc="#FFFFFF")
    box(ax, 73, 31, 40, 11, "MLP (baseline)", "Flatten \u2192 Dense 512\n\u2192 Dense 256 \u2192 Softmax", fc="#FFFFFF")
    box(ax, 50, 12, 74, 8, "Evaluation on the test set",
        "accuracy  |  macro precision / recall / F1  |  confusion matrix  |  timing")
    box(ax, 27, 0.5, 40, 8, "Saved outputs", "cnn_symbols.keras  |  results.json  |  figures")
    box(ax, 73, 0.5, 40, 8, "predict.py", "new image \u2192 symbol + confidence")
    for y1, y2 in ((72, 68), (60, 56), (48, 46)):
        arrow(ax, 50, y1, 50, y2)
    arrow(ax, 50, 21, 50, 16)
    arrow(ax, 38, 8, 27, 4.5); arrow(ax, 62, 8, 73, 4.5)
    save(fig, "fig_system.png")

def fig_cnn():
    fig, ax = plt.subplots(figsize=(7.4, 3.6)); ax.set_xlim(0, 100); ax.set_ylim(0, 47); ax.axis("off")
    ax.text(50, 45, "CNN: 357,524 trainable parameters (20 classes)", ha="center", fontsize=9.5, fontweight="bold")
    CONV, POOL, DENSE, AUG = "#F6E3E3", "#EDEDED", "#E3ECF6", "#FFF6D6"
    r1 = [("Input", "32 x 32 x 1", "#FFFFFF"), ("Augment", "rotate, shift, zoom\n(training only)", AUG),
          ("Conv 3x3, 32", "ReLU, same\n32x32x32  (320)", CONV), ("MaxPool 2", "16 x 16 x 32", POOL),
          ("Conv 3x3, 64", "ReLU, same\n16x16x64  (18,496)", CONV), ("MaxPool 2", "8 x 8 x 64", POOL)]
    r2 = [("Conv 3x3, 128", "ReLU, same\n8x8x128  (73,856)", CONV), ("MaxPool 2", "4 x 4 x 128", POOL),
          ("Flatten", "2,048 values", "#FFFFFF"), ("Dense 128", "ReLU\n(262,272)", DENSE),
          ("Dropout 0.5", "training only", "#FFFFFF"), ("Dense 20", "softmax\n(2,580)", DENSE)]
    xs = [9 + i * 16.4 for i in range(6)]
    for row, y in ((r1, 33), (r2, 12)):
        for i, (t, s, c) in enumerate(row):
            box(ax, xs[i], y, 14.6, 14, t, s, fc=c, fs=7.2, subfs=5.6)
            if i: arrow(ax, xs[i - 1] + 7.3, y, xs[i] - 7.3, y)
    ax.plot([xs[5], xs[5], xs[0]], [26, 22.5, 22.5], color="#222", lw=0.9)
    arrow(ax, xs[0], 22.5, xs[0], 19)
    save(fig, "fig_cnn.png")

# ------------------------------------------------------------------ styles
BODY = ParagraphStyle("body", fontName="Serif", fontSize=11, leading=14.2, alignment=TA_JUSTIFY, spaceAfter=5)
H1 = ParagraphStyle("h1", fontName="Serif-B", fontSize=19, leading=22, alignment=TA_CENTER, spaceBefore=2, spaceAfter=8)
H2 = ParagraphStyle("h2", fontName="Serif-B", fontSize=12.5, leading=15, spaceBefore=7, spaceAfter=3, keepWithNext=1)
BUL = ParagraphStyle("bul", parent=BODY, leftIndent=18, bulletIndent=4, spaceAfter=2.5)
CAP = ParagraphStyle("cap", fontName="Serif", fontSize=10.5, leading=13, alignment=TA_CENTER, spaceBefore=3, spaceAfter=7)
TC = ParagraphStyle("tc", fontName="Serif", fontSize=9.6, leading=11.6)
TCC = ParagraphStyle("tcc", parent=TC, alignment=TA_CENTER)
TH = ParagraphStyle("th", parent=TC, fontName="Serif-B", alignment=TA_CENTER)
CODE = ParagraphStyle("code", fontName="Mono", fontSize=7.9, leading=9.5, leftIndent=6, spaceAfter=5)
TCAP = ParagraphStyle("tcap", parent=CAP, spaceBefore=4, spaceAfter=3)

def P(t, s=BODY): return Paragraph(t, s)
def H(n, t): return Paragraph(f"{n} {t}".upper(), H2)
def bullets(items): return [Paragraph(t, BUL, bulletText="\u2022") for t in items]
def cap(n, t): return Paragraph(f"<b>{n}:</b> {t}", CAP)
def code(t): return Preformatted(t.strip("\n"), CODE)

def img(path, width_cm):
    w, h = PILImage.open(path).size
    return Image(str(path), width=width_cm * cm, height=width_cm * cm * h / w)

def placeholder(label, w_cm, h_cm):
    w, h = w_cm * cm, h_cm * cm
    d = Drawing(w, h)
    d.add(Rect(0, 0, w, h, fillColor=colors.HexColor("#FFFBD0"), strokeColor=colors.HexColor("#999999"),
               strokeDashArray=[4, 3], strokeWidth=0.8))
    d.add(String(w / 2, h / 2 + 4, label, textAnchor="middle", fontName="Serif-I", fontSize=10))
    d.add(String(w / 2, h / 2 - 9, "(created by train_cnn.py, then rebuild the report)", textAnchor="middle",
                 fontName="Serif-I", fontSize=8.5))
    d.hAlign = "CENTER"
    return d

def result_fig(file, label, w_cm, ph_h_cm):
    p = RES / file
    if R is not None and p.exists():
        return img(p, w_cm)
    return placeholder(label, w_cm * cm / cm, ph_h_cm)

def table(data, widths, header=True, align_first_left=True):
    rows = []
    for r, row in enumerate(data):
        rows.append([Paragraph(str(c), TH if (header and r == 0) else (TC if (c_i == 0 and align_first_left) else TC))
                     for c_i, c in enumerate(row)])
    t = Table(rows, colWidths=[w * cm for w in widths], repeatRows=1 if header else 0)
    st = [("GRID", (0, 0), (-1, -1), 0.6, colors.black), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
          ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
          ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4)]
    if header: st.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D9D9D9")))
    t.setStyle(TableStyle(st)); return t

# ------------------------------------------------------------------ page decorations
W, Hh = A4
def on_cover(c, doc):
    c.setLineWidth(1.3); c.rect(1.3 * cm, 1.3 * cm, W - 2.6 * cm, Hh - 2.6 * cm)

def on_front(c, doc):
    pass

def on_main(c, doc):
    n = c.getPageNumber() - 3
    c.setFont("Serif-B", 8.6); c.drawString(2.2 * cm, Hh - 1.55 * cm, TITLE)
    c.setStrokeColor(RED); c.setLineWidth(2.6); c.line(2.2 * cm, Hh - 1.85 * cm, W - 2.2 * cm, Hh - 1.85 * cm)
    c.setLineWidth(0.9); c.line(2.2 * cm, Hh - 2.05 * cm, W - 2.2 * cm, Hh - 2.05 * cm)
    c.setLineWidth(0.9); c.line(2.2 * cm, 1.95 * cm, W - 2.2 * cm, 1.95 * cm)
    c.setLineWidth(2.6); c.line(2.2 * cm, 1.75 * cm, W - 2.2 * cm, 1.75 * cm)
    c.setFillColor(colors.black); c.setFont("Serif-B", 9)
    c.drawString(2.2 * cm, 1.2 * cm, "Dept. of ISE, DBIT")
    c.drawCentredString(W / 2, 1.2 * cm, YEAR)
    c.drawRightString(W - 2.2 * cm - 14, 1.2 * cm, "Page"); c.setFont("Serif", 10)
    c.drawRightString(W - 2.2 * cm, 1.2 * cm, str(n))

# ------------------------------------------------------------------ story parts
def cover():
    S = lambda name, **kw: ParagraphStyle(name, alignment=TA_CENTER, **kw)
    def logo(path, w):
        p = HERE / "assets" / path
        if not p.exists(): return Spacer(1, 1 * cm)
        im = img(p, w); im.hAlign = "CENTER"; return im
    s = [Spacer(1, 0.5 * cm),
         P("VISVESVARAYA TECHNOLOGICAL UNIVERSITY", S("a", fontName="Serif-B", fontSize=17, leading=21)),
         P("\u201cJnana Sangama\u201d, Belgaum-590018, Karnataka, India", S("b", fontName="Serif-B", fontSize=9.5, leading=12)),
         Spacer(1, 0.2 * cm), logo("vtu.png", 4.0), Spacer(1, 0.6 * cm),
         P("MINI PROJECT REPORT", S("c", fontName="Serif-B", fontSize=17, leading=21)),
         P("On", S("d", fontName="Serif", fontSize=11, leading=13)), Spacer(1, 0.15 * cm),
         P(f"\u201c{TITLE}\u201d", S("e", fontName="Serif-B", fontSize=14.5, leading=17.5, textColor=RED)),
         Spacer(1, 0.3 * cm),
         P("Deep Learning", S("f", fontName="Serif", fontSize=13.5, leading=16)), Spacer(1, 0.4 * cm),
         P("BACHELOR OF ENGINEERING<br/>IN<br/>INFORMATION SCIENCE AND ENGINEERING",
           S("g", fontName="Serif-B", fontSize=10.5, leading=13)), Spacer(1, 0.4 * cm),
         P(f"Submitted by:<br/>{STUDENT} &nbsp;&nbsp;&nbsp;&nbsp; {USN}", S("h", fontName="Serif-B", fontSize=10.5, leading=14)),
         Spacer(1, 0.4 * cm),
         P(f"Under the Guidance of<br/><font size=12>{GUIDE}</font>", S("i", fontName="Serif-B", fontSize=11, leading=15)),
         P(f"{GUIDE_POST}<br/>DBIT, Bengaluru", S("j", fontName="Serif", fontSize=10.5, leading=13)),
         Spacer(1, 0.2 * cm), logo("dbit.png", 3.3), Spacer(1, 0.5 * cm),
         P("Department of Information Science &amp; Engineering", S("k", fontName="Serif-B", fontSize=15, leading=19)),
         P("DON BOSCO INSTITUTE OF TECHNOLOGY", S("l", fontName="Serif-B", fontSize=17.5, leading=21)),
         P("Kumbalagodu, Mysore Road, Bengaluru \u2013 560074", S("m", fontName="Serif-B", fontSize=10, leading=13)),
         Spacer(1, 0.2 * cm), P(YEAR, S("n", fontName="Serif-B", fontSize=10.5, leading=13))]
    return s

def abstract():
    acc, f1 = num(("cnn", "accuracy"), ".3f", "0.xxx"), num(("cnn", "f1"), ".3f", "0.xxx")
    acc2, f12 = num(("mlp", "accuracy"), ".3f", "0.xxx"), num(("mlp", "f1"), ".3f", "0.xxx")
    return [Paragraph("ABSTRACT", ParagraphStyle("ab", parent=H1, fontSize=17, spaceAfter=10)),
        P("Deep learning is a branch of machine learning in which neural networks with several layers learn "
          "useful patterns directly from data. This mini project, <b>Handwritten Mathematical Symbol Recognition "
          "using Deep Learning (CNN)</b>, builds the first stage of a handwritten mathematics reader: it "
          "recognises one isolated symbol at a time. Mathematical handwriting is difficult because the symbol "
          "set is large (digits, operators, brackets, Greek letters, integrals), many symbols look alike "
          "(1 and l, \u00d7 and x, ( and c) and every writer has a personal style. Hand-made rules on stroke "
          "length or pixel ratios break easily from writer to writer, so the features are learned from examples."),
        P("Each input image is converted to a 32 \u00d7 32 grayscale picture with bright strokes on a dark "
          "background and given to a Convolutional Neural Network (CNN) built with TensorFlow and Keras. The CNN "
          "has three convolution-and-pooling blocks, a dense layer of 128 units, dropout and a softmax output over "
          "20 classes (the digits 0\u20139 and the symbols + \u2212 \u00d7 \u00f7 = ( ) \u221a \u03c0 \u222b), "
          "357,524 trainable parameters in all. Rotation, shift and zoom augmentation imitates the variation "
          "between writers during training. A Multi-Layer Perceptron (MLP) with 661,268 parameters is trained "
          "on the same data as a baseline. The images are split 70/15/15 by stratified sampling and the test set "
          "is used only once, at the end."),
        P(f"On the unseen test set the CNN reached an accuracy of {acc} and a macro F1-score of {f1}, and the "
          f"MLP baseline {acc2} and {f12}. A confusion matrix shows which look-alike symbols are mixed up most "
          "often. All metrics are computed by scikit-learn from real test predictions, never typed in. The scores "
          "describe this dataset only: writers and writing styles outside it may behave differently, and the "
          "system recognises isolated symbols, not complete expressions.")]

def toc():
    rows = [["ABSTRACT", "i"], ["1. INTRODUCTION", "1"], ["2. THEORY", "2"], ["3. SYSTEM DESIGN", "4"],
            ["4. IMPLEMENTATION", "6"], ["5. RESULTS", "7"], ["6. ADVANTAGES", "10"], ["7. LIMITATIONS", "10"],
            ["8. FUTURE SCOPE", "10"], ["9. CONCLUSION", "11"], ["10. REFERENCES", "11"],
            ["11. PROJECT REPOSITORY", "11"]]
    data = [[Paragraph("<b>SL No.</b>", TC), Paragraph("<b>Page No</b>", ParagraphStyle("r", parent=TC, alignment=2))]]
    st = ParagraphStyle("t", fontName="Serif", fontSize=12, leading=15)
    for a, b in rows:
        data.append([Paragraph(a, st), Paragraph(b, ParagraphStyle("t2", parent=st, alignment=2))])
    t = Table(data, colWidths=[13.2 * cm, 3 * cm])
    t.setStyle(TableStyle([("BOTTOMPADDING", (0, 0), (-1, -1), 6), ("LINEBELOW", (0, 0), (-1, 0), 0.8, colors.black)]))
    return [Paragraph("TABLE OF CONTENTS", ParagraphStyle("tt", parent=H1, fontSize=17, spaceAfter=14)), t]

def intro():
    s = [P("1. INTRODUCTION", H1), H("1.1", "Background"),
         P("Writing is the most natural way to do mathematics: a student sketches an equation on paper or "
           "on a tablet long before typing it. Computers, however, cannot read that handwriting directly, and "
           "typing formulas in an editor takes time. Handwritten mathematical symbol recognition turns what a "
           "person writes into symbols a computer can store and process."),
         P("Mathematical notation is harder than ordinary text. The symbol set is large and mixes digits, "
           "operators, brackets and special signs; many pairs look alike (1 and l, \u00d7 and x, + and t, "
           "( and c); and slant, size, stroke thickness and position change from writer to writer. "
           "Hand-made rules such as stroke counts or pixel ratios are hard to tune for all writers. Deep learning "
           "lets a network learn the useful features straight from pixels. This project builds the first stage "
           "of a handwritten mathematics reader: a Convolutional Neural Network (CNN) [2] that classifies one "
           "isolated symbol image, compared with a plain Multi-Layer Perceptron (MLP) baseline. The system uses "
           "Python, TensorFlow/Keras [8], scikit-learn [9] and matplotlib."),
         H("1.2", "Problem statement"),
         P("Given an image of one handwritten mathematical symbol, predict which of 20 classes it belongs to: "
           "the digits 0\u20139 and the symbols + \u2212 \u00d7 \u00f7 = ( ) \u221a \u03c0 \u222b. The system must:")]
    s += bullets(["turn images of different size, colour and polarity into one standard network input;",
                  "tolerate differences between writers (slant, size, position, thickness) without overfitting "
                  "to the training images; and",
                  "report honest metrics computed from real test predictions, including per-class results and "
                  "the most confused pairs of symbols."])
    s += [H("1.3", "Objectives")]
    s += bullets(["To design and train a CNN that classifies handwritten mathematical symbols.",
                  "To build a preprocessing and augmentation pipeline and a stratified train / validation / test split.",
                  "To compare the CNN with an MLP baseline by accuracy, macro precision, recall and F1-score, "
                  "training time, parameters and inference time, and to analyse the confusion matrix."])
    s += [H("1.4", "Scope and data use"),
          P("The system recognises isolated symbols only: it does not cut a whole equation into symbols and "
            "does not understand structure such as fractions, powers or roots. The training images come from a "
            "public handwritten-symbol dataset used under its own licence (for example the CROHME-based "
            "collections [7]); no personal data other than handwriting samples is used. A prediction is an "
            "estimate with a confidence value, not a guarantee, and important results should be checked by eye.")]
    return s

def theory():
    s = [P("2. THEORY", H1), H("2.1", "Neural networks and training"),
         P("Deep learning uses neural networks with several layers. A neuron computes y = f(w \u00b7 x + b) from "
           "weights w, bias b and an activation f. <b>ReLU</b> [6], max(0, z), is used in the hidden layers. The last "
           "layer uses <b>softmax</b>, p<sub>k</sub> = exp(z<sub>k</sub>) / \u03a3 exp(z<sub>j</sub>), "
           "which turns 20 raw scores into 20 probabilities that add up to 1. "
           "The loss is the categorical cross-entropy, L = \u2013log p<sub>y</sub>, where y is the true class; "
           "the weights are adjusted by backpropagation with the Adam optimiser [3] (learning rate 0.001). "
           "<b>Dropout</b> [4] switches off 50% of the units of the dense layer during training, <b>early "
           "stopping</b> ends training when the validation loss stops improving, and <b>data augmentation</b> "
           "[5] shows slightly rotated, shifted and zoomed copies of the images. The data is split into "
           "training, validation and test sets; the test set is used only once, at the end."),
         H("2.2", "Convolutional Neural Network (CNN)"),
         P("A CNN [2] uses filters: small grids of weights that slide over the image, multiply and add the "
           "numbers under them: S(i, j) = \u03a3<sub>m</sub> \u03a3<sub>n</sub> I(i+m, j+n) \u00b7 K(m, n) + b. "
           "One filter is reused at every position (parameter sharing), so it finds a stroke wherever it occurs. "
           "Early filters respond to edges and short strokes, later layers combine them into curves, corners "
           "and whole shapes. A convolution layer with k \u00d7 k filters, C<sub>in</sub> input channels and "
           "C<sub>out</sub> filters has (k\u00b7k\u00b7C<sub>in</sub> + 1)\u00b7C<sub>out</sub> weights; the "
           "first layer here has (3\u00b73\u00b71 + 1)\u00b732 = 320."),
         KeepTogether([img(FIG / "fig_conv.png", 13.4), cap("Figure 2.1", "A 3 \u00d7 3 filter sliding over a symbol image")]),
         H("2.3", "Pooling, flatten and the output layer"),
         P("<b>Max-pooling</b> keeps the strongest response in every 2 \u00d7 2 block (Figure 2.2). It halves the "
           "width and height, makes the network less sensitive to small shifts and reduces the number of weights "
           "that follow. After three convolution-and-pooling blocks the 4 \u00d7 4 \u00d7 128 feature maps are "
           "<b>flattened</b> into one vector of 2,048 numbers; a dense layer combines them and the softmax layer "
           "gives one probability per class. The class with the highest probability is the prediction and its "
           "probability is the confidence."),
         KeepTogether([img(FIG / "fig_pool.png", 10.6), cap("Figure 2.2", "Max-pooling of a 4 \u00d7 4 feature map")]),
         H("2.4", "CNN and MLP compared; evaluation metrics"),
         P("The MLP baseline flattens the image into 1,024 numbers at once and connects every pixel to every "
           "neuron, so it has no built-in idea of neighbouring pixels or of the same stroke at a different place.", BODY),
         P("Table 2.1: The CNN and the MLP compared", TCAP),
         table([["Property", "CNN (main model)", "MLP (baseline)"],
                ["Reads", "32 \u00d7 32 image as a 2-D grid", "1,024 pixels as one flat list"],
                ["Learns", "Local stroke and shape patterns reused at every position",
                 "A separate weight for every pixel and neuron"],
                ["Layers", "Conv(32) \u2013 Pool \u2013 Conv(64) \u2013 Pool \u2013 Conv(128) \u2013 Pool \u2013 Dense(128) \u2013 Dropout \u2013 Softmax",
                 "Dense(512) \u2013 Dense(256) \u2013 Dropout \u2013 Softmax"],
                ["Parameters (20 classes)", "357,524", "661,268"]], [3.6, 7.0, 5.7]),
         Spacer(1, 6),
         P("From the confusion matrix, for each class: <b>precision</b> = TP / (TP + FP) (how many alarms for that "
           "symbol were right), <b>recall</b> = TP / (TP + FN) (how many written examples were found) and "
           "<b>F1</b> = 2PR / (P + R). <b>Accuracy</b> is the share of all test images classified correctly. "
           "The <b>macro</b> average is the plain mean over the 20 classes, so every symbol counts equally. In "
           "the confusion matrix rows are the true symbols and columns the predicted ones.")]
    return s

def system():
    s = [P("3. SYSTEM DESIGN", H1), H("3.1", "Overview and modules"),
         P("The system has four small Python files (Figure 3.1). <font name='Mono' size='9.5'>common.py</font> holds "
           "the preprocessing function used for both training and prediction, which avoids a train\u2013serve "
           "mismatch. <font name='Mono' size='9.5'>train_cnn.py</font> loads the images, splits them, builds and "
           "trains the CNN and the MLP, evaluates them on the test set and saves the model, "
           "<font name='Mono' size='9.5'>results.json</font> and the figures. "
           "<font name='Mono' size='9.5'>predict.py</font> classifies a new image with the saved model, and "
           "<font name='Mono' size='9.5'>build_report.py</font> builds this report from the saved results."),
         KeepTogether([img(FIG / "fig_system.png", 12.6), cap("Figure 3.1", "System architecture")]),
         H("3.2", "Preprocessing and augmentation"),
         P("Every image goes through the same five steps (Table 3.1). Only the augmentation step is random and it "
           "runs inside the model, so validation, test and live images are never altered."),
         P("Table 3.1: Preprocessing and augmentation steps", TCAP),
         table([["Step", "What is done", "Why"],
                ["1  Load", "Read the image and convert it to grayscale", "One channel is enough; colour carries no meaning"],
                ["2  Resize", "Scale to 32 \u00d7 32 pixels (bilinear)", "One fixed input size for the network"],
                ["3  Polarity", "If the mean intensity is above 127, invert", "Strokes are always bright on a dark background"],
                ["4  Scale", "Divide by 255, so values are 0 to 1", "Stable training, no scaler object needed"],
                ["5  Augment (training only)", "Rotate about \u00b110\u00b0, shift \u00b110%, zoom \u00b110%",
                 "Imitates writer variation. No flips: a mirrored \u201c(\u201d would become \u201c)\u201d"]],
               [3.5, 6.2, 6.6])]
    return s

def system2():
    s = [H("3.3", "Network design"),
         P("The CNN has three convolution blocks with 3 \u00d7 3 filters (32, 64 and 128 filters, ReLU, same "
           "padding), each followed by 2 \u00d7 2 max-pooling, so the image size goes 32 \u2192 16 \u2192 8 \u2192 4. "
           "A flatten layer (2,048 values), a dense layer of 128 units, dropout 0.5 and a softmax layer of 20 units "
           "follow: 357,524 parameters (Figure 3.2). The MLP baseline has dense layers of 512 and 256 units, "
           "dropout 0.5 and a softmax layer: 661,268 parameters. Both start with the same augmentation layers, "
           "which have no weights."),
         KeepTogether([img(FIG / "fig_cnn.png", 15.6), cap("Figure 3.2", "Architecture of the CNN")]),
         H("3.4", "Dataset, training and reproducibility"),
         P("<b>Dataset.</b> Images of handwritten mathematical symbols from a public collection such as the "
           "CROHME-based sets [7], one folder per class, 20 classes (digits 0\u20139 and + \u2212 \u00d7 \u00f7 = "
           "( ) \u221a \u03c0 \u222b). At most 2,000 images per class are used, drawn with a fixed random seed, "
           "which keeps the classes balanced and training fast on a CPU. The images are split 70/15/15 with "
           "stratification, so every class has the same share in the training, validation and test sets."),
         P("<b>Training.</b> Both networks use the same data, sparse categorical cross-entropy, Adam (learning "
           "rate 0.001), batch size 128, at most 30 epochs and early stopping on the validation loss (patience 5, "
           "best weights restored). The random seed is fixed (42)."),
         P("<b>Reproducibility.</b> One preprocessing function serves training and prediction; metrics are "
           "computed by scikit-learn from real test predictions and written to <font name='Mono' size='9.5'>"
           "results.json</font>, never typed by hand; the report is rebuilt from that file. Requirements: "
           "Python 3.10+, tensorflow 2.16+, scikit-learn, numpy, pillow, matplotlib, reportlab; a CPU is enough.")]
    return s

def implementation():
    s = [P("4. IMPLEMENTATION", H1), H("4.1", "Preprocessing"),
         P("The function below (common.py) is used by training and prediction. Images are read from one folder per class; "
           "labels are the folder positions."),
         code('''
def preprocess_image(img):
    g = np.asarray(img.convert("L").resize((IMG, IMG), Image.BILINEAR), dtype=np.float32)
    if g.mean() > 127:          # dark ink on white paper -> invert
        g = 255.0 - g
    return g / 255.0
'''),
         H("4.2", "The models"),
         code('''
kw = dict(fill_mode="constant", fill_value=0.0)          # augmentation, active only in training
aug = [layers.RandomRotation(0.03, **kw), layers.RandomTranslation(0.1, 0.1, **kw),
       layers.RandomZoom(0.1, **kw)]
cnn = keras.Sequential([
    keras.Input(shape=(32, 32, 1)), *aug,
    layers.Conv2D(32, 3, activation="relu", padding="same"), layers.MaxPooling2D(2),
    layers.Conv2D(64, 3, activation="relu", padding="same"), layers.MaxPooling2D(2),
    layers.Conv2D(128, 3, activation="relu", padding="same"), layers.MaxPooling2D(2),
    layers.Flatten(), layers.Dense(128, activation="relu"), layers.Dropout(0.5),
    layers.Dense(n_classes, activation="softmax")])
mlp = keras.Sequential([keras.Input(shape=(32, 32, 1)), *aug, layers.Flatten(),
    layers.Dense(512, activation="relu"), layers.Dense(256, activation="relu"),
    layers.Dropout(0.5), layers.Dense(n_classes, activation="softmax")])
'''),
         H("4.3", "Training, evaluation and prediction"),
         P("Both models are trained by the same function with a fixed seed. The split is stratified: 30% of the images "
           "are held out and halved into validation and test sets."),
         code('''
model.compile(optimizer=keras.optimizers.Adam(1e-3),
              loss="sparse_categorical_crossentropy", metrics=["accuracy"])
stop = keras.callbacks.EarlyStopping(monitor="val_loss", patience=5, restore_best_weights=True)
model.fit(Xtr, ytr, validation_data=(Xva, yva), epochs=30, batch_size=128, callbacks=[stop])
pred = model.predict(Xte, batch_size=256, verbose=0).argmax(axis=1)
p, r, f1, _ = precision_recall_fscore_support(yte, pred, average="macro", zero_division=0)
'''),
         P("After training, the script computes accuracy, macro precision, recall and F1, the confusion matrix, the "
           "five most frequent errors, the training time and the median time to classify a single image, and saves "
           "them with the training curves, the confusion matrix and a sample of predictions. "
           "<font name='Mono' size='9.5'>predict.py</font> loads the saved model, applies the same preprocessing to "
           "a new image, prints the three most likely symbols with their probabilities and warns when the "
           "highest probability is below 0.5. Commands: "
           "<font name='Mono' size='9'>python train_cnn.py --data_dir data --out_dir outputs</font>, "
           "<font name='Mono' size='9'>python predict.py my_symbol.png</font> and "
           "<font name='Mono' size='9'>python build_report.py outputs</font>.")]
    return s

def compare_text():
    if R is None:
        return ph("Write two or three sentences comparing the CNN and the MLP: which is more accurate and by how "
                  "many percentage points, and how parameters, training time and inference time differ.")
    c, m = R["cnn"], R["mlp"]; d = (c["accuracy"] - m["accuracy"]) * 100
    if abs(d) < 0.5:
        s = f"The two networks are about equally accurate (a difference of {abs(d):.2f} percentage points)"
    elif d > 0:
        s = f"The CNN is {d:.2f} percentage points more accurate than the MLP"
    else:
        s = f"The MLP is {-d:.2f} percentage points more accurate than the CNN"
    s += (f", with {'fewer' if c['params'] < m['params'] else 'more'} parameters "
          f"({c['params']:,} against {m['params']:,}). ")
    s += (f"The CNN needed {c['time_s']:.1f} s to train and {c['infer_ms']:.2f} ms per image; the MLP needed "
          f"{m['time_s']:.1f} s and {m['infer_ms']:.2f} ms.")
    return s

def results1():
    D = lambda k, l: num(("dataset", k), ",", l)
    intro_txt = (f"The models were trained on {num(('date',), '', 'date')} "
                 f"({num(('system',), '', 'OS')}, Python {num(('python',), '', 'x.y.z')}, TensorFlow "
                 f"{num(('tensorflow',), '', 'x.y.z')}); times depend on the hardware.")
    cnn_ep, mlp_ep = num(("cnn", "epochs"), "d", "n"), num(("mlp", "epochs"), "d", "n")
    if R is None:
        curve = ph("Say whether the validation curves follow the training curves (Figure 5.1)")
    else:
        gap = R["cnn"]["final_train_acc"] - R["cnn"]["final_val_acc"]
        curve = ("At the last epoch the validation accuracy is close to the training accuracy (Figure 5.1), so "
                 "there is no strong overfitting." if gap < 0.02 else
                 f"At the last epoch the training accuracy is {gap * 100:.1f} percentage points above the "
                 "validation accuracy (Figure 5.1), a sign of some overfitting.")
    t = lambda k, f, l: num(k, f, l)
    rows = [["Metric", "CNN", "MLP"],
            ["Test accuracy", t(("cnn", "accuracy"), ".3f", "0.xxx"), t(("mlp", "accuracy"), ".3f", "0.xxx")],
            ["Macro precision / recall",
             f"{t(('cnn','precision'), '.3f', '0.xxx')} / {t(('cnn','recall'), '.3f', '0.xxx')}",
             f"{t(('mlp','precision'), '.3f', '0.xxx')} / {t(('mlp','recall'), '.3f', '0.xxx')}"],
            ["Macro F1-score", t(("cnn", "f1"), ".3f", "0.xxx"), t(("mlp", "f1"), ".3f", "0.xxx")],
            ["Epochs run (maximum 30)", cnn_ep, mlp_ep],
            ["Training time (s) / parameters",
             f"{t(('cnn','time_s'), '.1f', 'xx.x')} / {g('cnn','params') or 357524:,}",
             f"{t(('mlp','time_s'), '.1f', 'xx.x')} / {g('mlp','params') or 661268:,}"],
            ["Inference per single image (median)", f"{t(('cnn','infer_ms'), '.2f', 'x.xx')} ms",
             f"{t(('mlp','infer_ms'), '.2f', 'x.xx')} ms"]]
    return [P("5. RESULTS", H1), P(intro_txt), H("5.1", "Dataset and split"),
            P(f"The dataset has {D('n_images', 'N')} images of 20 classes (at most 2,000 per class): training "
              f"{D('n_train', 'N')}, validation {D('n_val', 'N')} and test {D('n_test', 'N')}. The split is "
              "stratified, so every class has the same share in each part, and the test set was used only once, "
              "after training."),
            H("5.2", "Training and test-set results"),
            P(f"The CNN stopped after {cnn_ep} epochs ({t(('cnn','time_s'), '.1f', 'xx.x')} s) and the MLP after "
              f"{mlp_ep} epochs ({t(('mlp','time_s'), '.1f', 'xx.x')} s); the limit was 30. {curve}"),
            KeepTogether([result_fig("training_curves.png", "Figure 5.1: training and validation curves of the CNN", 14.0, 5.4),
                          cap("Figure 5.1", "Accuracy and loss per epoch of the CNN")]),
            P("Table 5.1: Test-set results", TCAP), table(rows, [7.3, 4.5, 4.5])]

def results2():
    if R is None:
        conf = ph("Name the weakest class and say which symbols are mixed up most often and why (similar shape)")
        crows = [["True symbol", "Predicted as", "Test images"]] + [[ph("symbol"), ph("symbol"), ph("n")] for _ in range(5)]
    else:
        pc = min(R["per_class"], key=lambda x: x["f1"])
        conf = (f"The class with the lowest F1-score is \u201c{pc['name']}\u201d (F1 = {pc['f1']:.3f}, precision "
                f"{pc['precision']:.3f}, recall {pc['recall']:.3f}). Table 5.2 lists the five most frequent errors "
                "of the CNN on the test set; the confusion matrix (Figure 5.2) shows all of them.")
        crows = [["True symbol", "Predicted as", "Test images"]] + [[c["true"], c["pred"], str(c["count"])] for c in R["top_confusions"]]
    return [KeepTogether([result_fig("confusion_cnn.png", "Figure 5.2: confusion matrix of the CNN on the test set", 11.5, 9.6),
                          cap("Figure 5.2", "Confusion matrix of the CNN on the test set")]),
            P(compare_text()),
            H("5.3", "Confusion analysis"), P(conf),
            P("Table 5.2: The five most frequent errors of the CNN", TCAP), table(crows, [5.4, 5.4, 5.4])]

def results3():
    return [H("5.4", "Sample predictions"),
            P("Figure 5.3 shows test images that the CNN classified correctly (top row, green) and incorrectly "
              "(bottom row, red), with the true and the predicted symbol above each image."),
            KeepTogether([result_fig("sample_predictions.png", "Figure 5.3: correct and wrong predictions", 15.0, 6.2),
                          cap("Figure 5.3", "Correct (top) and wrong (bottom) predictions on test images")]),
            P("The test scores show how well the model handles unseen images from the same dataset. They do not prove "
              "that it works for every person\u2019s handwriting; this limit is discussed in Section 7.")]

def closing():
    s = [P("6. ADVANTAGES", H1)]
    s += bullets(["Learns the features (strokes, curves, corners) directly from pixels; no hand-made rules or feature engineering.",
                  "Shared filters find a stroke wherever it is written; augmentation covers slant, shift and size.",
                  "Small and fast: 357,524 parameters, trained and run on a CPU; fewer parameters than the MLP baseline.",
                  "Honest and reproducible: fixed seed, one preprocessing function, stratified split, test set used once, "
                  "metrics computed from real predictions and saved to a file."])
    s += [P("7. LIMITATIONS", H1)]
    s += bullets(["Recognises one isolated symbol at a time; whole expressions need segmentation and structure analysis (fractions, powers, roots).",
                  "Only 20 classes. Letters are left out on purpose, because x and \u00d7 look alike; a larger symbol set "
                  "would increase confusion.",
                  "Trained and tested on one dataset: other writers, pens, paper or scanner conditions may give lower scores. "
                  "Low-resolution 32 \u00d7 32 input can lose thin strokes.",
                  "Look-alike symbols (for example 1 and a vertical bar, or + and \u00d7 drawn thinly) remain hard, and the "
                  "model always names one of its 20 classes, even for a symbol that is not among them."])
    s += [P("8. FUTURE SCOPE", H1)]
    s += bullets(["Segment full expressions and recognise structure, for example with an encoder\u2013decoder or attention model that outputs LaTeX.",
                  "Add more classes (letters, Greek letters, functions), use transfer learning or deeper networks, and tune hyper-parameters.",
                  "Use online pen-stroke data with an LSTM or GRU, add a \u201cnot a symbol\u201d class or a confidence threshold, "
                  "and explain predictions with Grad-CAM.",
                  "Build a drawing-canvas web or mobile app and export a lightweight model (TensorFlow Lite or ONNX)."])
    return s

def ending():
    acc, f1 = num(("cnn", "accuracy"), ".3f", "0.xxx"), num(("cnn", "f1"), ".3f", "0.xxx")
    repo = REPO_URL or ph("https://github.com/&lt;your-username&gt;/&lt;repository-name&gt;")
    refs = ["[1] I. Goodfellow, Y. Bengio and A. Courville, <i>Deep Learning</i>, MIT Press, 2016.",
            "[2] Y. LeCun, L. Bottou, Y. Bengio and P. Haffner, \u201cGradient-based learning applied to document recognition,\u201d "
            "Proc. IEEE, vol. 86, no. 11, pp. 2278\u20132324, 1998.",
            "[3] D. P. Kingma and J. Ba, \u201cAdam: A method for stochastic optimization,\u201d ICLR, 2015.",
            "[4] N. Srivastava et al., \u201cDropout: A simple way to prevent neural networks from overfitting,\u201d JMLR, vol. 15, pp. 1929\u20131958, 2014.",
            "[5] P. Y. Simard, D. Steinkraus and J. C. Platt, \u201cBest practices for convolutional neural networks applied to visual document analysis,\u201d ICDAR, 2003.",
            "[6] V. Nair and G. E. Hinton, \u201cRectified linear units improve restricted Boltzmann machines,\u201d ICML, 2010.",
            "[7] H. Mouch\u00e8re, C. Viard-Gaudin, R. Zanibbi and U. Garain, \u201cICFHR 2014 competition on recognition of on-line handwritten mathematical expressions (CROHME 2014),\u201d ICFHR, 2014.",
            "[8] M. Abadi et al., \u201cTensorFlow: Large-scale machine learning on heterogeneous systems,\u201d 2015, tensorflow.org.",
            "[9] F. Pedregosa et al., \u201cScikit-learn: Machine learning in Python,\u201d JMLR, vol. 12, pp. 2825\u20132830, 2011.",
            "[10] TensorFlow, Keras, scikit-learn, Pillow and matplotlib documentation: tensorflow.org, keras.io, scikit-learn.org, pillow.readthedocs.io, matplotlib.org."]
    RS = ParagraphStyle("ref", parent=BODY, fontSize=9.6, leading=11.8, leftIndent=24, firstLineIndent=-24, spaceAfter=2.5, alignment=0)
    return ([P("9. CONCLUSION", H1),
             P("This project built a deep-learning classifier for isolated handwritten mathematical symbols. Every image is "
               "standardised to 32 \u00d7 32 grayscale, a CNN with three convolution-and-pooling blocks reads it, and a softmax "
               "layer gives a probability for each of 20 classes. On the unseen test set the CNN reached an accuracy of "
               f"{acc} and a macro F1-score of {f1}. The comparison with an MLP baseline, the per-class results and the "
               "confusion analysis show where the CNN helps and which look-alike symbols still fail. Because all scores come "
               "from one dataset, they describe the model on that data, not on every writer; recognising complete expressions "
               "needs symbol segmentation and structure analysis, which are left as future work."),
             P("10. REFERENCES", H1)] + [Paragraph(r, RS) for r in refs] +
            [P("11. PROJECT REPOSITORY", H1), P(repo, ParagraphStyle("repo", parent=BODY, alignment=TA_CENTER))])

# ------------------------------------------------------------------ build
def build():
    for f in (fig_conv, fig_pool, fig_system, fig_cnn): f()
    doc = BaseDocTemplate(str(OUT), pagesize=A4, title=TITLE.title(), author=STUDENT)
    fc = Frame(2.2 * cm, 1.2 * cm, W - 4.4 * cm, Hh - 2.4 * cm, id="c", leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    fm = Frame(2.2 * cm, 2.25 * cm, W - 4.4 * cm, Hh - 2.25 * cm - 2.55 * cm, id="m", leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    ff = Frame(2.2 * cm, 2.0 * cm, W - 4.4 * cm, Hh - 4.5 * cm, id="f", leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    doc.addPageTemplates([PageTemplate("cover", [fc], onPage=on_cover), PageTemplate("front", [ff], onPage=on_front),
                          PageTemplate("main", [fm], onPage=on_main)])
    story = cover() + [NextPageTemplate("front"), PageBreak()] + abstract() + [PageBreak()] + toc() + \
        [NextPageTemplate("main"), PageBreak()]
    story += intro() + [PageBreak()] + theory() + [PageBreak()] + system() + [PageBreak()] + system2() + [PageBreak()]
    story += implementation() + [PageBreak()] + results1() + [PageBreak()] + results2() + [PageBreak()] + results3() + [PageBreak()]
    story += closing() + [PageBreak()] + ending()
    doc.build(story)
    print("written", OUT)

if __name__ == "__main__":
    build()
